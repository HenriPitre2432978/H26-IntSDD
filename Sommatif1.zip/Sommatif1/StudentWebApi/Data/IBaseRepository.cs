﻿namespace Data
{
    public interface IBaseRepository
    {
        public void SaveChanges();
    }
}
