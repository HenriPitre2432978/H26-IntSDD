﻿namespace Models.DTO
{
    public class GenderDTO
    {
        public int GenderID { get; set; }
        public string Name { get; set; }
        public GenderDTO()
        {

        }
    }
}