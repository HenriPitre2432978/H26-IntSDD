﻿namespace Models.DTO
{
    public class DepartmentDTO
    {
        public int DepartmentID { get; set; }
        public string Name { get; set; }
        public DepartmentDTO()
        {
        }
    }
}